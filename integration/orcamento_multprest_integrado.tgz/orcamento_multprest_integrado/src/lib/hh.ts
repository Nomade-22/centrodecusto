export interface HHConfig {
  id: number;
  salary_minimum: number;
  prize: number;
  prize_in_charges: boolean;
  insalubrity_pct: number;
  monthly_hours: number;
  productive_employees: number;
  employer_inss_rat_fap_pct: number;
  fgts_pct: number;
  fgts_fine_pct: number;
  das_effective_pct: number;
  default_iss_retained_pct: number;
  default_inss_retained_pct: number;
  markup_pct: number;
  anticipation_daily_pct: number;
  epi_monthly: number;
  exams_monthly: number;
  tools_monthly: number;
  health_monthly: number;
  lunch_monthly: number;
  transport_monthly: number;
  insurance_total_monthly: number;
  training_annual: number;
}

export interface HHClientRule {
  client_id: string;
  name: string;
  dias: number;
  negotiation_pct: number;
  iss_retained_pct: number;
  inss_retained_pct: number;
  anticipate: boolean;
}

export interface HHWorkerInput {
  worker_id: string;
  salary_base: number;
}

export interface HHFixedCost {
  id?: number;
  name: string;
  amount: number;
  sort_order?: number;
}

export interface HHWorkerResult {
  salaryBase: number;
  insalubrity: number;
  chargeBase: number;
  vacation: number;
  vacationThird: number;
  vacationWithThird: number;
  thirteenth: number;
  fgtsBase: number;
  fgtsVacation: number;
  fgtsThirteenth: number;
  fgtsTotal: number;
  employerBase: number;
  employerVacation: number;
  employerThirteenth: number;
  employerTotal: number;
  terminationReserve: number;
  individualMonthly: number;
  fixedCostPerWorker: number;
  insurancePerWorker: number;
  trainingMonthly: number;
  totalMonthlyCost: number;
  costPerHour: number;
  targetProfitPerHour: number;
}

export interface HHClientPriceResult {
  clientId: string;
  costPerHour: number;
  basePricePerHour: number;
  offerPricePerHour: number;
  simpleTaxPerHour: number;
  issRetainedPerHour: number;
  dasPayablePerHour: number;
  inssRetainedPerHour: number;
  anticipationCostPerHour: number;
  economicResultPerHour: number;
  economicMarginPct: number;
}

const n = (value: unknown) => Number(value) || 0;
const clamp = (value: number, min: number, max: number) =>
  Math.min(max, Math.max(min, n(value)));

export function calculateWorkerHH(
  config: HHConfig,
  worker: HHWorkerInput,
  fixedCostsTotal: number,
): HHWorkerResult {
  const salaryBase = n(worker.salary_base);
  const insalubrity = n(config.salary_minimum) * n(config.insalubrity_pct) / 100;
  const chargeBase = salaryBase + insalubrity + (config.prize_in_charges ? n(config.prize) : 0);

  const vacation = chargeBase / 12;
  const vacationThird = vacation / 3;
  const vacationWithThird = vacation + vacationThird;
  const thirteenth = chargeBase / 12;

  const fgtsRate = n(config.fgts_pct) / 100;
  const fgtsBase = chargeBase * fgtsRate;
  const fgtsVacation = vacationWithThird * fgtsRate;
  const fgtsThirteenth = thirteenth * fgtsRate;
  const fgtsTotal = fgtsBase + fgtsVacation + fgtsThirteenth;

  const employerRate = n(config.employer_inss_rat_fap_pct) / 100;
  const employerBase = chargeBase * employerRate;
  const employerVacation = vacationWithThird * employerRate;
  const employerThirteenth = thirteenth * employerRate;
  const employerTotal = employerBase + employerVacation + employerThirteenth;

  const terminationReserve = fgtsTotal * n(config.fgts_fine_pct) / 100;

  const individualMonthly =
    n(config.epi_monthly) +
    n(config.exams_monthly) +
    n(config.tools_monthly) +
    n(config.health_monthly) +
    n(config.lunch_monthly) +
    n(config.transport_monthly);

  const employees = Math.max(1, Math.round(n(config.productive_employees)));
  const fixedCostPerWorker = n(fixedCostsTotal) / employees;
  const insurancePerWorker = n(config.insurance_total_monthly) / employees;
  const trainingMonthly = n(config.training_annual) / 12;

  const totalMonthlyCost =
    salaryBase +
    insalubrity +
    n(config.prize) +
    vacationWithThird +
    thirteenth +
    fgtsTotal +
    employerTotal +
    terminationReserve +
    individualMonthly +
    fixedCostPerWorker +
    insurancePerWorker +
    trainingMonthly;

  const hours = Math.max(1, n(config.monthly_hours));
  const costPerHour = totalMonthlyCost / hours;
  const targetProfitPerHour = costPerHour * n(config.markup_pct) / 100;

  return {
    salaryBase,
    insalubrity,
    chargeBase,
    vacation,
    vacationThird,
    vacationWithThird,
    thirteenth,
    fgtsBase,
    fgtsVacation,
    fgtsThirteenth,
    fgtsTotal,
    employerBase,
    employerVacation,
    employerThirteenth,
    employerTotal,
    terminationReserve,
    individualMonthly,
    fixedCostPerWorker,
    insurancePerWorker,
    trainingMonthly,
    totalMonthlyCost,
    costPerHour,
    targetProfitPerHour,
  };
}

export function calculateClientHHPrice(
  config: HHConfig,
  client: HHClientRule,
  workerCost: HHWorkerResult,
): HHClientPriceResult {
  const dasRate = clamp(n(config.das_effective_pct) / 100, 0, 0.95);
  const issRate = clamp(n(client.iss_retained_pct) / 100, 0, dasRate);
  const inssRetRate = clamp(n(client.inss_retained_pct) / 100, 0, Math.max(0, 0.95 - issRate));
  const receivableFraction = Math.max(0, 1 - issRate - inssRetRate);

  const anticipationRate = client.anticipate
    ? Math.max(0, n(client.dias)) * Math.max(0, n(config.anticipation_daily_pct)) / 100
    : 0;
  const financialFractionOnInvoice = anticipationRate * receivableFraction;

  const targetWithMarkup = workerCost.costPerHour * (1 + n(config.markup_pct) / 100);
  const divisor = Math.max(0.01, 1 - dasRate - financialFractionOnInvoice);
  const basePricePerHour = targetWithMarkup / divisor;

  const negotiationRate = clamp(n(client.negotiation_pct) / 100, 0, 0.95);
  const offerPricePerHour = negotiationRate > 0
    ? basePricePerHour / (1 - negotiationRate)
    : basePricePerHour;

  const simpleTaxPerHour = basePricePerHour * dasRate;
  const issRetainedPerHour = basePricePerHour * issRate;
  const dasPayablePerHour = basePricePerHour * Math.max(0, dasRate - issRate);
  const inssRetainedPerHour = basePricePerHour * inssRetRate;
  const netReceivable = basePricePerHour - issRetainedPerHour - inssRetainedPerHour;
  const anticipationCostPerHour = netReceivable * anticipationRate;
  const economicResultPerHour =
    basePricePerHour - simpleTaxPerHour - anticipationCostPerHour - workerCost.costPerHour;
  const economicMarginPct = basePricePerHour > 0
    ? economicResultPerHour / basePricePerHour * 100
    : 0;

  return {
    clientId: client.client_id,
    costPerHour: workerCost.costPerHour,
    basePricePerHour,
    offerPricePerHour,
    simpleTaxPerHour,
    issRetainedPerHour,
    dasPayablePerHour,
    inssRetainedPerHour,
    anticipationCostPerHour,
    economicResultPerHour,
    economicMarginPct,
  };
}
